﻿(function(){

})();

$(function(){


});	