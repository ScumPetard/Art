<?php

namespace App\Http\Controllers\Admin;

use App\Models\ClickRecord;
use App\Models\Module;
use Carbon\Carbon;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class StatisticalController extends Controller
{
    public function index()
    {

        $tongjs = Module::all()->map(function ($t) {
            return collect([
                'label' => $t->name,
                'data' =>ClickRecord::where(['module_id' => $t->id])->count(),
                'color' => '#3c8dbc'
            ]);
        });
        $times = ClickRecord::orderBy('created_at','desc')->get()->map(function ($gate) {
            $gate->today = substr($gate->created_at->parse('today')->toDateTimeString(),0,10);
            return $gate;
        });
        $timeArray = [];
        foreach ($times as $time) {

            if (!isset($timeArray[$time->today])) {
                $timeArray[$time->today] = [];
            }
            $timeArray[$time->today][] = $time->toArray();
        }

        foreach ($timeArray as $key => $value) {
            $data = [
                '首页' => 0,
                '中国国画' => 0,
                '中国书法' => 0,
                '唐卡壁画' => 0,
                '日本版画' => 0,
                '印章印谱' => 0,
                '碑帖古籍' => 0,
                '艺术家' => 0,
                '西方油画' => 0,
                '汇总' => 0,
            ];
            foreach ($value as $item) {
                $module = Module::find($item['module_id']);
                $data[$module->name] += 1;
                $data['汇总'] ++;
            }
            $timeArray[$key] = $data;
        }
        $timeArray  = collect($timeArray);
        return view('admin.statistical.index',compact('tongjs','timeArray'));
    }
}
